<?php

$con=mysqli_connect("localhost","root","","learning");

if(mysqli_connect_error())
{
    echo"cannot connect";
}


?>